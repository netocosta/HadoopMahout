/**
 * Core interfaces for functions, comparisons and procedures on objects and primitive data types.
 */
package org.apache.mahout.math.function;
