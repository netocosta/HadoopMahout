/**
 * Tools for basic and advanced statistics: Estimators, Gamma functions, Beta functions, Probabilities,
 * Special integrals, etc.
 */
package org.apache.mahout.math.jet.stat;
